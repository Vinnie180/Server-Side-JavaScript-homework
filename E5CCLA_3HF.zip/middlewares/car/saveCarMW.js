/**
 * Save a car to the database
 */

var requireOption = require('../common').requireOption;