/**
 * Get a car from the database by id
 */

var requireOption = require('../common').requireOption;