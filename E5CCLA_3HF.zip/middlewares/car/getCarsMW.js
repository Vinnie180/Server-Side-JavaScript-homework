/**
 * Get all cars from the database
 */

var requireOption = require('../common').requireOption;