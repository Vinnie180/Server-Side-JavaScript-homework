/**
 * Delete a car from the database
 */

var requireOption = require('../common').requireOption;
