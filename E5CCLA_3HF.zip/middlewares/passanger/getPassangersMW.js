/**
 * Get all passangers from the database
 * and put them on res.locals.passangers
 */

var requireOption = require('../common').requireOption;