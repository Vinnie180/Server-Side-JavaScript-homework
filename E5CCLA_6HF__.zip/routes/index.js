const renderMW = require('../middlewares/generic/renderMW');

const getCarsMW = require('../middlewares/car/getCarsMW');
const getCarMW = require('../middlewares/car/getCarMW');
const saveCarMW = require('../middlewares/car/saveCarMW');
const delCarMW = require('../middlewares/car/delCarMW');

const getPassengersMW = require('../middlewares/passenger/getPassengersMW');
const getPassengerMW = require('../middlewares/passenger/getPassengerMW');
const savePassengerMW = require('../middlewares/passenger/savePassengerMW');
const delPassengerMW = require('../middlewares/passenger/delPassengerMW');

module.exports = function (app) {
    const objRepo = {};

    app.use('/cars/new',
        saveCarMW(objRepo),
        renderMW(objRepo, 'carForm')
    );

    app.use('/cars/edit/:carid',
        getCarMW(objRepo),
        saveCarMW(objRepo),
        renderMW(objRepo, 'carForm')
    );

    app.get('/cars/del/:carid',
        getCarMW(objRepo),
        delCarMW(objRepo),
        function (req, res, next) {
            return res.redirect('/cars');
        }
    );

    app.use('/cars',
        getCarsMW(objRepo),
        renderMW(objRepo, 'index')
    );

    app.get('/passengers/:carid',
        getPassengersMW(objRepo),
        renderMW(objRepo, 'passengers')
    );

    app.use('/passengers/:carid/new',
        savePassengerMW(objRepo),
        renderMW(objRepo, 'passengerForm')
    );

    app.use('/passengers/:carid/:passengerid',
        getPassengerMW(objRepo),
        savePassengerMW(objRepo),
        renderMW(objRepo, 'passengerForm')
    );

    app.get('/passengers/:carid/del/:passengerid',
        getPassengerMW(objRepo),
        delPassengerMW(objRepo),
        function (req, res, next) {
            req.params.carid = 123;
            return res.redirect('/passengers/' + req.params.carid);
        }
    );

    app.get('/',
        function (req, res, next) {
            return res.redirect('/cars');
        }
    )
}