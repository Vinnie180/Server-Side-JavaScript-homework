/**
 * Get all cars from the database
 */