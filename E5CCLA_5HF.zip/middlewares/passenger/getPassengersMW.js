/**
 * Get all passangers from the database
 * and put them on res.locals.passangers
 */