/**
 * Delete a car from the database
 */