/**
 * Get a car from the database by id
 */