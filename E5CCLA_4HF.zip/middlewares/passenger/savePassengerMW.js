/**
 * Save a car to the database
 */
